from kyt import *

@bot.on(events.CallbackQuery(data=b'registrasi'))
async def ganti_ip(event):
    async def ganti_ip_(event):
        chat = event.chat_id  # Definisikan variabel chat di sini
        async with bot.conversation(chat) as pw:
            await event.respond("**Ingrese la IP de la VPS:**")
            pw = await pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text

        async with bot.conversation(chat) as user:
            await event.respond('**Nombre de Usuario:**')
            user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            
        async with bot.conversation(chat) as day:
            await event.respond("**Dias de Vencimiento:**",buttons=[
[Button.inline(" 7 Dias ","7"),
Button.inline(" 15 Dias ","15")],
[Button.inline(" 30 Dias ","30"),
Button.inline(" 60 Dias ","60")]])
            day = await day.wait_event(events.CallbackQuery)
            day = (await day).data.decode("ascii")
            
        await event.edit("Procesando.")
        time.sleep(1)
        await event.edit("`Procesando Registro de IP VPS`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera...Configurando Registro`")
        cmd = f'printf "%s\n" "###" "{user}" "{day}" "{pw}" |  bash /root/usr/bin/add-ip-bot'
        try:
           a = subprocess.run(cmd, shell=True).decode("utf-8")
        except:  
            await event.respond("**Usuario Ya Existe**")
        else:  
            
msg = f"""
━━━━━━━━━━━━━━━━━━━
**🍀VPS REGSITRADO EXITOSAMENTE🍀
━━━━━━━━━━━━━━━━━━━
**🌹NOMBRE DEL AUTOR : {user}
**🏵️EXPIRACION DE SCRIPT : {day} day
**🌺IP DEL SERVIDOR : {pw}
━━━━━━━━━━━━━━━━━━━
**Creador By Jerry™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
            await event.respond(msg)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ganti_ip_(event)
    else:
        await event.answer("Acceso Denegado", alert=True)
