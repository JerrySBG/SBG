from kyt import *

@bot.on(events.CallbackQuery(data=b'registrasi'))
async def ganti_ip(event):
    async def ganti_ip_(event):
        chat = event.chat_id  # Definisikan variabel chat di sini
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Nombre de Usuario:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text.strip()

        async with bot.conversation(chat) as pw_conv:
            await event.respond("**IP VPS:**")
            pw = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw.raw_text.strip()
            
        async with bot.conversation(chat) as day_conv:
            await event.respond("**Dias de Vencimiento:**")
            day = await day_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            day = day.raw_text.strip()
            
        await event.edit("Procesando.")
        await event.edit("Procesando..")
        await event.edit("Procesando...")
        await event.edit("Procesando....")
        time.sleep(1)
        await event.edit("`Procesando Registro de IP VPS`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera...Configurando Registro`")

        cmd = f'printf "%s\n" "{pw}" "{user}" "{day}" |  bash /root/usr/bin/add-ip'
        try:
            subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**🍀VPS SUCCESSFULLY REGISTER🍀**
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**🌹NAME AUTHOR : {user}**
**🏵️SCRIPT TIME : {day} day**
**🌺IP SERVER   : {pw}**
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ganti_ip_(event)
    else:
        await event.answer("Acceso Denegado", alert=True)
