from kyt import *

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
	async def create_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Usuario:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Cuota:**",buttons=[
[Button.inline(" 1 GB ","1"),
Button.inline(" 15 GB ","15")],
[Button.inline(" 150 GB ","150"),
Button.inline(" ILIMITADO ","3000")]])
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).data.decode("ascii")
		async with bot.conversation(chat) as exp:
			await event.respond("**Escoger Dias de Expiración**",buttons=[
[Button.inline(" 7 Dias ","7"),
Button.inline(" 15 Dias ","15")],
[Button.inline(" 30 Dias ","30"),
Button.inline(" 60 Dias ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addss-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️  SHDWSCSK ACCOUNT 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
» Remarks     : `{user}`
» Host Server : `{DOMAIN}`
» Host XrayDNS: `{HOST}`
» User Quota  : `Unlimited`
» Pub Key     : `{PUB}`
» Port TLS    : `222-1000`
» Port GRPC   : `443`
» Port DNS    : `443, 53`
» Password    : `{uuid}`
» Cipers      : `aes-128-gcm`
» NetWork     : `(WS) or (gRPC)`
» Path        : `(/multi path)/ss-ws`
» ServiceName : `ss-grpc`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS    :
`{x[0]}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link gRPC   :
`{x[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link JSON  : `https://${DOMAIN}:81/ss-{user}.txt`
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_shadowsocks_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
	async def cek_shadowsocks_(event):
		cmd = 'bot-cek-ss'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Usuarios Shadowsocks Registrados
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
""",buttons=[[Button.inline("‹ Regresar ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_shadowsocks_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
	async def delete_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Usuario:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-delss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario no Encontrado**")
		else:
			msg = f"""**Borrado Exitosamente**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_shadowsocks_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
	async def trial_shadowsocks_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Elija Minutos de Vencimiento**",buttons=[
[Button.inline(" 10 Minutos ","10"),
Button.inline(" 15 Minutos ","15")],
[Button.inline(" 30 Minutos ","30"),
Button.inline(" 60 Minutos ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion del Servidor...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'printf "%s\n" "{exp}" | bot-trialss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ SHDWSCSK Account 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
» Remarks     : `{remarks}`
» Host Server : `{DOMAIN}`
» Host XrayDNS: `{HOST}`
» User Quota  : `Unlimited`
» Pub Key     : `{PUB}`
» Port TLS    : `222-1000`
» Port GRPC   : `443`
» Port DNS    : `443, 53`
» Password    : `{uuid}`
» Cipers      : `aes-128-gcm`
» NetWork     : `(WS) or (gRPC)`
» Path        : `(/multi path)/ss-ws`
» ServiceName : `ss-grpc`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS   :
`{x[0]}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link gRPC  :
`{x[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link JSON  : `https://${DOMAIN}:81/ss-{remarks}.txt`
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El : `{exp} Minutes`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
	async def shadowsocks_(event):
		inline = [
[Button.inline(" TRIAL SHDWSCSK ","trial-shadowsocks"),
Button.inline(" CREAR SHDWSCSK ","create-shadowsocks")],
[Button.inline(" CHECAR SHDWSCSK ","cek-shadowsocks"),
Button.inline(" BORRAR SHDWSCSK ","delete-shadowsocks")],
[Button.inline("‹ REGRESAR ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
◇━━━━━━━━━━━━━━━━━◇ 
🐾🕊️ SHDWSK MANAGER 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
🔰 » Service: `SHADOWSOCKS`
🔰 » Hostname/IP: `{DOMAIN}`
🔰 » ISP: `{z["isp"]}`
🔰 » Country: `{z["country"]}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
◇━━━━━━━━━━━━━━━━━◇
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)
