from kyt import *

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Usuario:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Cuota:**",buttons=[
[Button.inline(" 1 GB ","1"),
Button.inline(" 15 GB ","15")],
[Button.inline(" 150 GB ","150"),
Button.inline(" ILIMITADO ","3000")]])
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Escoge Dias de Expiración**",buttons=[
[Button.inline(" 7 Dias ","7"),
Button.inline(" 15 Dias ","15")],
[Button.inline(" 30 Dias ","30"),
Button.inline(" 60 Dias ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addtr-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ Xray/Trojan Account 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
» Remarks     : `{user}`
» Host Server : `{domain}`
» Host XrayDNS: `{HOST}`
» User Quota  : `{pw} GB`
» Port DNS    : `443, 53`
» port TLS    : `222-1000`
» User ID     : `{uuid}`
» Pub Key     : {PUB}
◇━━━━━━━━━━━━━━━━━━━◇
» Link WS    :
`{b[0].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC  :
`{b[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : `https://{domain}:81/trojan-{user}.txt`
◇━━━━━━━━━━━━━━━━━━━◇
Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'bot-cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Muestra Usuarios Trojan Registrados
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
""",buttons=[[Button.inline("‹ Regresar Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Escoge Minutos de Expiración**",buttons=[
[Button.inline(" 10 Minutos ","10"),
Button.inline(" 15 Minutos ","15")],
[Button.inline(" 30 Minutos ","30"),
Button.inline(" 60 Minutos ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{exp}" | bot-trialtr'
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			remarks = re.search("#(.*)",b[0]).group(1)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ Xray/Trojan Account 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
» Remarks     : `{remarks}`
» Host Server : `{domain}`
» Host XrayDNS: `{HOST}`
» User Quota  : `Unlimited`
» Port DNS    : `443, 53`
» port TLS    : `222-1000`
» Path Trojan : `(/multi path)/trojan-ws`
» User ID     : `{uuid}`
» Pub Key     : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link WS    :
`{b[0].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC  :
`{b[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{exp} Minutes`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Usuario:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-deltr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario No Encontrado**")
		else:
			msg = f"""**Borrado Exitosamente**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" TRIAL TROJAN ","trial-trojan"),
Button.inline(" CREAR TROJAN ","create-trojan")],
[Button.inline(" CHECK TROJAN ","cek-trojan"),
Button.inline(" BORRAR TROJAN ","delete-trojan")],
[Button.inline("‹ REGRESAR ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ TROJAN MANAGER 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
🔰 » Service : `TROJAN`
🔰 » Hostname/IP : `{DOMAIN}`
🔰 » ISP : `{z["isp"]}`
🔰 » Country: `{z["country"]}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
◇━━━━━━━━━━━━━━━━━◇
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
