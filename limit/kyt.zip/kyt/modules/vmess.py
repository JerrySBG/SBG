from kyt import *

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'crear-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Nombre de Usuario:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Limite de Usuario:**",buttons=[
[Button.inline(" 1 USUARIO ","1"),
Button.inline(" 2 USUARIOS ","2")],
[Button.inline(" 3 USUARIO ","3"),
Button.inline(" 4 USUARIOS ","4")],
[Button.inline(" 5 USUARIOS ","5"),
Button.inline(" ILIMITADO ","1000")]])
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw2:
			await event.respond("**Limite Cuota de Usuario:**",buttons=[
[Button.inline(" 1 GB ","1"),
Button.inline(" 15 GB ","15")],
[Button.inline(" 150 GB ","150"),
Button.inline(" ILIMITADO ","3000")]])
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text	
		async with bot.conversation(chat) as exp:
			await event.respond("**Escoger Dias de Expiración**",buttons=[
[Button.inline(" 7 Dias ","7"),
Button.inline(" 15 Dias ","15")],
[Button.inline(" 30 Dias ","30"),
Button.inline(" 60 Dias ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{uuid}" "{pw}" "{pw2}" | addws-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
#			c = [x.group() for x in re.finditer("Host XrayDNS(.*)",a)]
#			d = [x.group() for x in re.finditer("Pub Key(.*)",a)]
			print(b)
#			print(d)
#			print(c)
#			xx = re.search("Pub Key      :(.*)",d[0]).group(1)
#			xxx = re.search("Host XrayDNS :(.*)",d[0]).group(1)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ Xray/Vmess Account 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
» Remarks      : `{z["ps"]}`
» Domain       : `{z["add"]}`
» XRAY DNS     : `{HOST}`
» Limit IP     : `{pw} IP`
» User Cuota   : `{pw2} GB`
» Port DNS     : `443, 53`
» port TLS     : `222-1000`
» Port NTLS    : `80, 8080, 8081-9999`
» Port GRPC    : `443`
» User ID      : `{z["id"]}`
» AlterId      : `0`
» Security     : `auto`
» NetWork      : `(WS) or (gRPC)`
» Path TLS     : `(/multi path)/vmess`
» Path NLS     : `(/multi path)/vmess`
» Path Dynamic : `http://google.com`
» ServiceName  : `vmess-grpc`
» Pub Key      : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS     :
`{b[0].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS    :
`{b[1].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC    :
`{b[2].strip("'")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vmess-{user}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

#CRATE VMESS ID
@bot.on(events.CallbackQuery(data=b'id-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Nombre de Usuario:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as uuid:
			await event.respond('**Id o Presiona Enter para un Aletorio:**')
			uuid = uuid.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			uuid = (await uuid).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Limite de Usuario:**",buttons=[
[Button.inline(" 1 USUARIO ","1"),
Button.inline(" 2 USUARIOS ","2")],
[Button.inline(" 3 USUARIO ","3"),
Button.inline(" 4 USUARIOS ","4")],
[Button.inline(" 5 USUARIOS ","5"),
Button.inline(" ILIMITADO ","1000")]])
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as pw2:
			await event.respond("**Limite Cuota de Usuario:**",buttons=[
[Button.inline(" 1 GB ","1"),
Button.inline(" 15 GB ","15")],
[Button.inline(" 150 GB ","150"),
Button.inline(" ILIMITADO ","3000")]])
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text	
		async with bot.conversation(chat) as exp:
			await event.respond("**Escoger Dias de Expiración**",buttons=[
[Button.inline(" 7 Dias ","7"),
Button.inline(" 15 Dias ","15")],
[Button.inline(" 30 Dias ","30"),
Button.inline(" 60 Dias ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{uuid}" "{pw}" "{pw2}" | addwsid-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
#			c = [x.group() for x in re.finditer("Host XrayDNS(.*)",a)]
#			d = [x.group() for x in re.finditer("Pub Key(.*)",a)]
			print(b)
#			print(d)
#			print(c)
#			xx = re.search("Pub Key      :(.*)",d[0]).group(1)
#			xxx = re.search("Host XrayDNS :(.*)",d[0]).group(1)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ Xray/Vmess Account 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
» Remarks      : `{z["ps"]}`
» Domain       : `{z["add"]}`
» XRAY DNS     : `{HOST}`
» Limit IP     : `{pw} IP`
» User Cuota   : `{pw2} GB`
» Port DNS     : `443, 53`
» port TLS     : `222-1000`
» Port NTLS    : `80, 8080, 8081-9999`
» Port GRPC    : `443`
» User ID      : `{z["id"]}`
» AlterId      : `0`
» Security     : `auto`
» NetWork      : `(WS) or (gRPC)`
» Path TLS     : `(/multi path)/vmess`
» Path NLS     : `(/multi path)/vmess`
» Path Dynamic : `http://BUG.COM`
» ServiceName  : `vmess-grpc`
» Pub Key      : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS     :
`{b[0].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS    :
`{b[1].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC    :
`{b[2].strip("'")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vmess-{user}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

# CUENTA TEMPORAL VMESS
@bot.on(events.CallbackQuery(data=b'temporal-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as pup:
			await event.respond("**Escoge Minutos de Expiración**",buttons=[
[Button.inline(" 10 Minutos ","10"),
Button.inline(" 15 Minutos ","15")],
[Button.inline(" 30 Minutos ","30"),
Button.inline(" 60 Minutos ","60")]])
			pup = pup.wait_event(events.CallbackQuery)
			pup = (await pup).data.decode("ascii")
		await event.edit("Procesando.")
		await event.edit("Procesando..")
		await event.edit("Procesando...")
		await event.edit("Procesando....")
		time.sleep(3)
		await event.edit("`Procesando Informacion de Cuenta...`")
		time.sleep(1)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(3)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espera... Configurando una Cuenta`")
		cmd = f'printf "%s\n" "{pup}" | bot-trialws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario Ya Existe**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ Xray/Vmess Account 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
» Remarks      : `{z["ps"]}`
» Domain       : `{z["add"]}`
» XRAY DNS     : `{HOST}`
» User Cuota   : `1`
» Limit IP     : `3`
» Port DNS     : `443, 53`
» port TLS     : `222-1000`
» Port NTLS    : `80, 8080, 8081-9999`
» Port GRPC    : `443`
» User ID      : `{z["id"]}`
» AlterId      : `0`
» Security     : `auto`
» NetWork      : `(WS) or (gRPC)`
» Path TLS     : `(/multi path)/vmess`
» Path NLS     : `(/multi path)/vmess`
» Path Dynamic : `http://BUG.COM`
» ServiceName  : `vmess-grpc`
» Pub Key      : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS     :
`{b[0].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS    :
`{b[1].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC    :
`{b[2].strip("'")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vmess-{z["ps"]}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira En: `{pup} Minutos`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

#CHECAR USUARIOS VMESS
@bot.on(events.CallbackQuery(data=b'checar-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Usuarios Vmess Registrados
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
""",buttons=[[Button.inline("‹ Regresar Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'borrar-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Usuario No Encontrado**")
		else:
			msg = f"""**Borrado Exitosamente**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" TRIAL VMESS ","temporal-vmess")],
[Button.inline(" CREAR VMESS ","crear-vmess"),
Button.inline(" CREAR VMESS ID","id-vless")],
[Button.inline(" CHECK VMESS ","checar-vmess"),
Button.inline(" BORRAR VMESS ","borrar-vmess")],
[Button.inline("‹ REGRESAR ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🐾🕊️ VMESS MANAGER 🕊️🐾
◇━━━━━━━━━━━━━━━━━◇
🔰 » Service: `VMESS`
🔰 » Hostname/IP: `{DOMAIN}`
🔰 » ISP: `{z["isp"]}`
🔰 » Country: `{z["country"]}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
